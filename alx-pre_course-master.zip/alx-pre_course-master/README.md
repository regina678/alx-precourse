My first readme
updated
